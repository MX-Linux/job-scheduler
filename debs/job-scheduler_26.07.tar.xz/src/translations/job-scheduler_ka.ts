<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ka">
<context>
    <name>CronModel</name>
    <message>
        <location filename="../src/CronModel.cpp" line="128"/>
        <source>Time</source>
        <translation>დრო</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="130"/>
        <source>User</source>
        <translation>მომხმარებელი</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="132"/>
        <source>Command</source>
        <translation>ბრძანება</translation>
    </message>
</context>
<context>
    <name>ExecuteList</name>
    <message>
        <location filename="../src/ExecuteList.cpp" line="43"/>
        <source>Max Item</source>
        <translation>მაქს. ელემენტი</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="45"/>
        <source>Max Date</source>
        <translation>მაქს. თარიღი</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="47"/>
        <source>Select</source>
        <translation>აირჩიეთ</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="52"/>
        <source>&amp;Update</source>
        <translation>განა&amp;ხლება</translation>
    </message>
</context>
<context>
    <name>ExecuteModel</name>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="65"/>
        <source>Execute Time</source>
        <translation>გაშვების დრო</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="67"/>
        <source>Time</source>
        <translation>დრო</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="69"/>
        <source>User</source>
        <translation>მომხმარებელი</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="71"/>
        <source>Command</source>
        <translation>ბრძანება</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/MainWindow.cpp" line="56"/>
        <source>&amp;Command</source>
        <translation>ბ&amp;რძანება</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="58"/>
        <source>&amp;Variables</source>
        <translation>ც&amp;ვლადები</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="60"/>
        <source>&amp;Job List</source>
        <translation>&amp;დავალებების სია</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="99"/>
        <location filename="../src/MainWindow.cpp" line="194"/>
        <location filename="../src/MainWindow.cpp" line="254"/>
        <location filename="../src/MainWindow.cpp" line="275"/>
        <location filename="../src/MainWindow.cpp" line="344"/>
        <source>Job Scheduler</source>
        <translation>დავალებების მგეგმავი</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="126"/>
        <source>&amp;File</source>
        <translation>&amp;ფაილი</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="127"/>
        <source>File</source>
        <translation>ფაილი</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="130"/>
        <source>&amp;New Item</source>
        <translation>ახალი ელემე&amp;ნტი</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="131"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="134"/>
        <source>&amp;Reload</source>
        <translation>თავიდან ჩატვი&amp;რთვა</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="135"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="137"/>
        <source>&amp;Save</source>
        <translation>&amp;შენახვა</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="138"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="141"/>
        <source>Start as &amp;Root</source>
        <translation>გაშვება Root მომხმა&amp;რებლით</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="143"/>
        <source>Start as &amp;Regular user</source>
        <translation>გაშვება ჩვეულებ&amp;რივი მომხმარებლით</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="145"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="148"/>
        <source>E&amp;xit</source>
        <translation>გა&amp;სვლა</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="149"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="156"/>
        <source>&amp;Edit</source>
        <translation>ჩასწორ&amp;ება</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="157"/>
        <source>Edit</source>
        <translation>ჩასწორება</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="159"/>
        <source>Cu&amp;t</source>
        <translation>ამოჭ&amp;რა</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="160"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="162"/>
        <source>&amp;Copy</source>
        <translation>&amp;კოპირება</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="163"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="165"/>
        <source>&amp;Paste</source>
        <translation>&amp;ჩასმა</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="166"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="169"/>
        <source>&amp;Delete</source>
        <translation>&amp;წაშლა</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="170"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="181"/>
        <location filename="../src/MainWindow.cpp" line="183"/>
        <source>&amp;Help</source>
        <translation>&amp;დახმარება</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="182"/>
        <source>&amp;About</source>
        <translation>შეს&amp;ახებ</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="255"/>
        <source>Not saved since last change.
Are you OK to reload?</source>
        <translation>ბოლო ცვლილების შემდეგ შენახვა არ მომხდარა.
გნებავთ თავიდან ჩატვირთვა?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="344"/>
        <source>Not saved since last change.
Are you OK to exit?</source>
        <translation>ბოლო ცვლილების შემდეგ შენახვა არ მომხდარა.
გნებავთ გასვლა?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="357"/>
        <source>About Job Scheduler</source>
        <translation>დავალებების მგეგმავის შესახებ</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="358"/>
        <source>&lt;b&gt;Job Scheduler&lt;/b&gt;</source>
        <translation>&lt;b&gt;დავალებების მგეგმავი&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="358"/>
        <source>Version: %1</source>
        <translation>ვერსია: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="359"/>
        <source>Job Scheduler is based upon qroneko 0.5.4, released in 2005 by korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</source>
        <translation>დავალებების მგეგმავი დაბუძნებულია qroneko 0.5.4-ზე, რომელიც გამოვიდა 2005-ში. ავტორი: korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="362"/>
        <source>Original project page: %1</source>
        <translation>ორიგინალი პროექტის გვერდი: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="366"/>
        <source>MX project page: %1</source>
        <translation>MX-ის პროექტის გვერდი: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="371"/>
        <source>%1 License</source>
        <translation>ლიცენზია %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="52"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>License</source>
        <translation>ლიცენზია</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <location filename="../src/about.cpp" line="84"/>
        <source>Changelog</source>
        <translation>ცვლილებების ჟურნალი</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="32"/>
        <location filename="../src/about.cpp" line="99"/>
        <source>&amp;Close</source>
        <translation>&amp;დახურვა</translation>
    </message>
</context>
<context>
    <name>SaveDialog</name>
    <message>
        <location filename="../src/SaveDialog.cpp" line="21"/>
        <source>Save New Schedule</source>
        <translation>ახალი განრიგის შენახვა</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="34"/>
        <source>User:</source>
        <translation>მომხმარებელი:</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="42"/>
        <source>&amp;OK</source>
        <translation>&amp;დიახ</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="43"/>
        <source>&amp;Cancel</source>
        <translation>&amp;გაუქმება</translation>
    </message>
</context>
<context>
    <name>TCommandEdit</name>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="43"/>
        <source>User:</source>
        <translation>მომხმარებელი:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="51"/>
        <source>Time:</source>
        <translation>დრო:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="55"/>
        <source>Time String E&amp;ditor</source>
        <translation>&amp;დროის სტრიქონის რედაქტორი</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="60"/>
        <source>Command:</source>
        <translation>ბრძანება:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="66"/>
        <source>Comment:</source>
        <translation>კომენტარი:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="69"/>
        <source>Job Schedule:</source>
        <translation>დავალების გეგმა:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="132"/>
        <source>Time Format Error</source>
        <translation>დროის ფორმატის შეცდომა</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="146"/>
        <source>No matching schedule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="155"/>
        <source>Today</source>
        <translation>დღეს</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="157"/>
        <source>Tomorrow</source>
        <translation>ხვალ</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../src/TimeDialog.cpp" line="80"/>
        <source>time</source>
        <translation>დრო</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="85"/>
        <source>Minute</source>
        <translation>წუთი</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="97"/>
        <source>Hour</source>
        <translation>საათი</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="103"/>
        <source>AM </source>
        <translation>AM </translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="109"/>
        <source>PM </source>
        <translation>PM </translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="116"/>
        <source>Day</source>
        <translation>დღე</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="131"/>
        <source>Month</source>
        <translation>თვე</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="145"/>
        <source>Week</source>
        <translation>კვირა</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="157"/>
        <source>Simple</source>
        <translation>მარტივი</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="171"/>
        <source>Enable Literal</source>
        <translation>მუდმივის ჩართვა</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="173"/>
        <source>&amp;Reset</source>
        <translation>ჩამოყ&amp;რა</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="174"/>
        <source>&amp;Cancel</source>
        <translation>&amp;გაუქმება</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="175"/>
        <source>&amp;Ok</source>
        <translation>&amp;დიახ</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="189"/>
        <source>The current time expression is invalid. Please fix it or cancel.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>VariableEdit</name>
    <message>
        <location filename="../src/VariableEdit.cpp" line="50"/>
        <source>Variables</source>
        <translation>ცვლადები</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="55"/>
        <source>Mail:</source>
        <translation>ელფოსტა:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="56"/>
        <source>Don&apos;t send</source>
        <translation>არ გააგზავნო</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="57"/>
        <source>Send</source>
        <translation>გაგზავნა</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="58"/>
        <source>To</source>
        <translation>სადამდე</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="70"/>
        <source>&amp;New</source>
        <translation>&amp;ახალი</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="73"/>
        <source>&amp;Delete</source>
        <translation>&amp;წაშლა</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="81"/>
        <source>Name:</source>
        <translation>სახელი:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="86"/>
        <source>Value:</source>
        <translation>მნიშვნელობა:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="89"/>
        <source>Comment:</source>
        <translation>კომენტარი:</translation>
    </message>
</context>
<context>
    <name>VariableModel</name>
    <message>
        <location filename="../src/VariableModel.cpp" line="37"/>
        <source>Name</source>
        <translation>სახელი</translation>
    </message>
    <message>
        <location filename="../src/VariableModel.cpp" line="39"/>
        <source>Value</source>
        <translation>მნიშვნელობა</translation>
    </message>
</context>
</TS>