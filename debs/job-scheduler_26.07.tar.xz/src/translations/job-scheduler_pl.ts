<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pl">
<context>
    <name>CronModel</name>
    <message>
        <location filename="../src/CronModel.cpp" line="128"/>
        <source>Time</source>
        <translation>Czas</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="130"/>
        <source>User</source>
        <translation>Użytkownik</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="132"/>
        <source>Command</source>
        <translation>Polecenie</translation>
    </message>
</context>
<context>
    <name>ExecuteList</name>
    <message>
        <location filename="../src/ExecuteList.cpp" line="43"/>
        <source>Max Item</source>
        <translation>Max elementów</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="45"/>
        <source>Max Date</source>
        <translation>Max dat</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="47"/>
        <source>Select</source>
        <translation>Wybierz</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="52"/>
        <source>&amp;Update</source>
        <translation>&amp;Aktualizuj</translation>
    </message>
</context>
<context>
    <name>ExecuteModel</name>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="65"/>
        <source>Execute Time</source>
        <translation>Czas wykonania</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="67"/>
        <source>Time</source>
        <translation>Czas</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="69"/>
        <source>User</source>
        <translation>Użytkownik</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="71"/>
        <source>Command</source>
        <translation>Polecenie</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/MainWindow.cpp" line="56"/>
        <source>&amp;Command</source>
        <translation>P&amp;olecenie</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="58"/>
        <source>&amp;Variables</source>
        <translation>Z&amp;mienne</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="60"/>
        <source>&amp;Job List</source>
        <translation>&amp;Lista zadań</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="99"/>
        <location filename="../src/MainWindow.cpp" line="194"/>
        <location filename="../src/MainWindow.cpp" line="254"/>
        <location filename="../src/MainWindow.cpp" line="275"/>
        <location filename="../src/MainWindow.cpp" line="344"/>
        <source>Job Scheduler</source>
        <translation>Harmonogram zadań</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="126"/>
        <source>&amp;File</source>
        <translation>&amp;Plik</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="127"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="130"/>
        <source>&amp;New Item</source>
        <translation>&amp;Nowe zadanie</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="131"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="134"/>
        <source>&amp;Reload</source>
        <translation>P&amp;rzeładuj</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="135"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="137"/>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="138"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="141"/>
        <source>Start as &amp;Root</source>
        <translation>Uruchom jako Roo&amp;t</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="143"/>
        <source>Start as &amp;Regular user</source>
        <translation>Uruchom jako Zwykły &amp;użytkownik</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="145"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="148"/>
        <source>E&amp;xit</source>
        <translation>Za&amp;kończ</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="149"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="156"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edytuj</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="157"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="159"/>
        <source>Cu&amp;t</source>
        <translation>&amp;Wytnij</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="160"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="162"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="163"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="165"/>
        <source>&amp;Paste</source>
        <translation>Wkl&amp;ej</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="166"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="169"/>
        <source>&amp;Delete</source>
        <translation>&amp;Usuń</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="170"/>
        <source>Del</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="181"/>
        <location filename="../src/MainWindow.cpp" line="183"/>
        <source>&amp;Help</source>
        <translation>Pomo&amp;c</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="182"/>
        <source>&amp;About</source>
        <translation>O pro&amp;gramie</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="255"/>
        <source>Not saved since last change.
Are you OK to reload?</source>
        <translation>Nie zapisano od ostatniej zmiany.
Czy na pewno chcesz załadować ponownie?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="344"/>
        <source>Not saved since last change.
Are you OK to exit?</source>
        <translation>Nie zapisano od ostatniej zmiany.
Czy na pewno chcesz zakończyć?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="357"/>
        <source>About Job Scheduler</source>
        <translation>O Harmonogramie zadań</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="358"/>
        <source>&lt;b&gt;Job Scheduler&lt;/b&gt;</source>
        <translation>&lt;b&gt;Harmonogram zadań&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="358"/>
        <source>Version: %1</source>
        <translation>Wersja: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="359"/>
        <source>Job Scheduler is based upon qroneko 0.5.4, released in 2005 by korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</source>
        <translation>Harmonogram zadań jest oparty na qroneko 0.5.4, wydanym w 2005 przez korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="362"/>
        <source>Original project page: %1</source>
        <translation>Oryginalna strona projektu: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="366"/>
        <source>MX project page: %1</source>
        <translation>Strona projektu MX: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="371"/>
        <source>%1 License</source>
        <translation>%1 Licencja</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="52"/>
        <source>Could not load %1</source>
        <translation>Nie udało się załadować %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>License</source>
        <translation>Licencja</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <location filename="../src/about.cpp" line="84"/>
        <source>Changelog</source>
        <translation>Dziennik zmian</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation>Nie udało się załadować dziennika zmian.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="32"/>
        <location filename="../src/about.cpp" line="99"/>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
</context>
<context>
    <name>SaveDialog</name>
    <message>
        <location filename="../src/SaveDialog.cpp" line="21"/>
        <source>Save New Schedule</source>
        <translation>Zapisz nowy harmonogram</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="34"/>
        <source>User:</source>
        <translation>Użytkownik:</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="42"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="43"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
</context>
<context>
    <name>TCommandEdit</name>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="43"/>
        <source>User:</source>
        <translation>Użytkownik:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="51"/>
        <source>Time:</source>
        <translation>Czas:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="55"/>
        <source>Time String E&amp;ditor</source>
        <translation>Edytor &amp;czasu</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="60"/>
        <source>Command:</source>
        <translation>Polecenie:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="66"/>
        <source>Comment:</source>
        <translation>Komentarz:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="69"/>
        <source>Job Schedule:</source>
        <translation>Harmonogram zadań:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="132"/>
        <source>Time Format Error</source>
        <translation>Błąd formatu czasu</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="146"/>
        <source>No matching schedule</source>
        <translation>Brak pasującego harmonogramu</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="155"/>
        <source>Today</source>
        <translation>Dzisiaj</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="157"/>
        <source>Tomorrow</source>
        <translation>Jutro</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../src/TimeDialog.cpp" line="80"/>
        <source>time</source>
        <translation>czas</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="85"/>
        <source>Minute</source>
        <translation>Minuta</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="97"/>
        <source>Hour</source>
        <translation>Godzina</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="103"/>
        <source>AM </source>
        <translation>AM </translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="109"/>
        <source>PM </source>
        <translation>PM </translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="116"/>
        <source>Day</source>
        <translation>Dzień</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="131"/>
        <source>Month</source>
        <translation>Miesiąc</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="145"/>
        <source>Week</source>
        <translation>Tydzień</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="157"/>
        <source>Simple</source>
        <translation>Po prostu</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="171"/>
        <source>Enable Literal</source>
        <translation>Włącz dosłowne</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="173"/>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="174"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="175"/>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="189"/>
        <source>The current time expression is invalid. Please fix it or cancel.</source>
        <translation>Wyrażenie czasu bieżącego jest nieprawidłowe. Popraw je lub anuluj.</translation>
    </message>
</context>
<context>
    <name>VariableEdit</name>
    <message>
        <location filename="../src/VariableEdit.cpp" line="50"/>
        <source>Variables</source>
        <translation>Zmienne</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="55"/>
        <source>Mail:</source>
        <translation>Mail:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="56"/>
        <source>Don&apos;t send</source>
        <translation>Nie wysyłaj</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="57"/>
        <source>Send</source>
        <translation>Wyślij</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="58"/>
        <source>To</source>
        <translation>Do</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="70"/>
        <source>&amp;New</source>
        <translation>&amp;Nowy</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="73"/>
        <source>&amp;Delete</source>
        <translation>&amp;Usuń</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="81"/>
        <source>Name:</source>
        <translation>Nazwa:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="86"/>
        <source>Value:</source>
        <translation>Wartość:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="89"/>
        <source>Comment:</source>
        <translation>Komentarz:</translation>
    </message>
</context>
<context>
    <name>VariableModel</name>
    <message>
        <location filename="../src/VariableModel.cpp" line="37"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/VariableModel.cpp" line="39"/>
        <source>Value</source>
        <translation>Wartość</translation>
    </message>
</context>
</TS>