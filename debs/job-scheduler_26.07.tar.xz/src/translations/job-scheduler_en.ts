<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CronModel</name>
    <message>
        <location filename="../src/CronModel.cpp" line="128"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="130"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="132"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExecuteList</name>
    <message>
        <location filename="../src/ExecuteList.cpp" line="43"/>
        <source>Max Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="45"/>
        <source>Max Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="47"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="52"/>
        <source>&amp;Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="96"/>
        <source>No matching schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="99"/>
        <source>Time Format Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExecuteModel</name>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="65"/>
        <source>Execute Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="67"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="69"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="71"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/MainWindow.cpp" line="56"/>
        <source>&amp;Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="58"/>
        <source>&amp;Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="60"/>
        <source>&amp;Job List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="99"/>
        <location filename="../src/MainWindow.cpp" line="112"/>
        <location filename="../src/MainWindow.cpp" line="119"/>
        <location filename="../src/MainWindow.cpp" line="124"/>
        <location filename="../src/MainWindow.cpp" line="129"/>
        <location filename="../src/MainWindow.cpp" line="207"/>
        <location filename="../src/MainWindow.cpp" line="270"/>
        <location filename="../src/MainWindow.cpp" line="291"/>
        <location filename="../src/MainWindow.cpp" line="360"/>
        <source>Job Scheduler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="112"/>
        <source>Failed to start job-scheduler-launcher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="119"/>
        <location filename="../src/MainWindow.cpp" line="124"/>
        <source>Failed to determine the login user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="129"/>
        <source>Failed to start job-scheduler as %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="139"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="140"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="143"/>
        <source>&amp;New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="144"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="147"/>
        <source>&amp;Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="148"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="150"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="151"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="154"/>
        <source>Start as &amp;Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="156"/>
        <source>Start as &amp;Regular user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="158"/>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="161"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="162"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="169"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="170"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="172"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="173"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="175"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="176"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="178"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="179"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="182"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="183"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="194"/>
        <location filename="../src/MainWindow.cpp" line="196"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="195"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="271"/>
        <source>Not saved since last change.
Are you OK to reload?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="360"/>
        <source>Not saved since last change.
Are you OK to exit?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="373"/>
        <source>About Job Scheduler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="374"/>
        <source>&lt;b&gt;Job Scheduler&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="374"/>
        <source>Version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="375"/>
        <source>Job Scheduler is based upon qroneko 0.5.4, released in 2005 by korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="378"/>
        <source>Original project page: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="382"/>
        <source>MX project page: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="387"/>
        <source>%1 License</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="52"/>
        <source>Could not load %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <location filename="../src/about.cpp" line="84"/>
        <source>Changelog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="32"/>
        <location filename="../src/about.cpp" line="99"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveDialog</name>
    <message>
        <location filename="../src/SaveDialog.cpp" line="21"/>
        <source>Save New Schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="34"/>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="42"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="43"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TCommandEdit</name>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="52"/>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="60"/>
        <source>Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="64"/>
        <source>Time String E&amp;ditor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="69"/>
        <source>Command:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="76"/>
        <source>Comment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="79"/>
        <source>Job Schedule:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="178"/>
        <source>Warning: &quot;%1&quot; was not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="187"/>
        <source>Time Format Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="201"/>
        <source>No matching schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="210"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="212"/>
        <source>Tomorrow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../src/TimeDialog.cpp" line="80"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="85"/>
        <source>Minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="97"/>
        <source>Hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="103"/>
        <source>AM </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="109"/>
        <source>PM </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="116"/>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="131"/>
        <source>Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="145"/>
        <source>Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="157"/>
        <source>Simple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="171"/>
        <source>Enable Literal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="173"/>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="174"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="175"/>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="188"/>
        <source>Time format error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="189"/>
        <source>The current time expression is invalid. Please fix it or cancel.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VariableEdit</name>
    <message>
        <location filename="../src/VariableEdit.cpp" line="49"/>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="54"/>
        <source>Mail:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="55"/>
        <source>Don&apos;t send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="56"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="57"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="69"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="72"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="80"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="85"/>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="88"/>
        <source>Comment:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VariableModel</name>
    <message>
        <location filename="../src/VariableModel.cpp" line="37"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/VariableModel.cpp" line="39"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
