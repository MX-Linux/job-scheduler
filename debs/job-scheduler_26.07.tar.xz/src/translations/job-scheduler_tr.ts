<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="tr">
<context>
    <name>CronModel</name>
    <message>
        <location filename="../src/CronModel.cpp" line="128"/>
        <source>Time</source>
        <translation>Zaman</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="130"/>
        <source>User</source>
        <translation>Kullanıcı</translation>
    </message>
    <message>
        <location filename="../src/CronModel.cpp" line="132"/>
        <source>Command</source>
        <translation>Komut</translation>
    </message>
</context>
<context>
    <name>ExecuteList</name>
    <message>
        <location filename="../src/ExecuteList.cpp" line="43"/>
        <source>Max Item</source>
        <translation>En fazla Öğe</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="45"/>
        <source>Max Date</source>
        <translation>En İleri Tarih</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="47"/>
        <source>Select</source>
        <translation>Seç</translation>
    </message>
    <message>
        <location filename="../src/ExecuteList.cpp" line="52"/>
        <source>&amp;Update</source>
        <translation>&amp;Güncelleme</translation>
    </message>
</context>
<context>
    <name>ExecuteModel</name>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="65"/>
        <source>Execute Time</source>
        <translation>Yürütme Zamanı</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="67"/>
        <source>Time</source>
        <translation>Zaman</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="69"/>
        <source>User</source>
        <translation>Kullanıcı</translation>
    </message>
    <message>
        <location filename="../src/ExecuteModel.cpp" line="71"/>
        <source>Command</source>
        <translation>Komut</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/MainWindow.cpp" line="56"/>
        <source>&amp;Command</source>
        <translation>&amp;Komut</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="58"/>
        <source>&amp;Variables</source>
        <translation>&amp;Değişkenler</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="60"/>
        <source>&amp;Job List</source>
        <translation>&amp;İş Listesi</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="99"/>
        <location filename="../src/MainWindow.cpp" line="194"/>
        <location filename="../src/MainWindow.cpp" line="254"/>
        <location filename="../src/MainWindow.cpp" line="275"/>
        <location filename="../src/MainWindow.cpp" line="344"/>
        <source>Job Scheduler</source>
        <translation>İş Çizelgeleyici</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="126"/>
        <source>&amp;File</source>
        <translation>&amp;Dosya</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="127"/>
        <source>File</source>
        <translation>Dosya</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="130"/>
        <source>&amp;New Item</source>
        <translation>&amp;Yeni Öğe</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="131"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="134"/>
        <source>&amp;Reload</source>
        <translation>&amp;Yeniden yükle</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="135"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="137"/>
        <source>&amp;Save</source>
        <translation>&amp;Kaydet</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="138"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="141"/>
        <source>Start as &amp;Root</source>
        <translation>&amp;Kök olarak Başlat</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="143"/>
        <source>Start as &amp;Regular user</source>
        <translation>&amp;Normal kullanıcı olarak Başlat</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="145"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="148"/>
        <source>E&amp;xit</source>
        <translation>Çıkış</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="149"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="156"/>
        <source>&amp;Edit</source>
        <translation>&amp;Düzenle</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="157"/>
        <source>Edit</source>
        <translation>Düzenle</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="159"/>
        <source>Cu&amp;t</source>
        <translation>Kes</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="160"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="162"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopyala</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="163"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="165"/>
        <source>&amp;Paste</source>
        <translation>&amp;Yapıştır</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="166"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="169"/>
        <source>&amp;Delete</source>
        <translation>&amp;Sil</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="170"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="181"/>
        <location filename="../src/MainWindow.cpp" line="183"/>
        <source>&amp;Help</source>
        <translation>&amp;Yardım</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="182"/>
        <source>&amp;About</source>
        <translation>&amp;Hakkında</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="255"/>
        <source>Not saved since last change.
Are you OK to reload?</source>
        <translation>Son değişiklikten beri kaydedilmedi
Yeniden yüklemeye hazır mısınız?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="344"/>
        <source>Not saved since last change.
Are you OK to exit?</source>
        <translation>Son değişiklikten beri kaydedilmedi
Çıkmaya hazır mısınız?</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="357"/>
        <source>About Job Scheduler</source>
        <translation>İş Çizelgeleyici Hakkında</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="358"/>
        <source>&lt;b&gt;Job Scheduler&lt;/b&gt;</source>
        <translation>&lt;b&gt;İş Çizelgeleyici&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="358"/>
        <source>Version: %1</source>
        <translation>Sürüm: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="359"/>
        <source>Job Scheduler is based upon qroneko 0.5.4, released in 2005 by korewaisai (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</source>
        <translation>İş Çizelgeleyici, 2005 yılında korewaisai tarafından yayınlanan qroneko 0.5.4’e dayanmaktadır (&lt;a href=&quot;mailto:korewaisai@yahoo.co.jp&quot;&gt;korewaisai@yahoo.co.jp&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="362"/>
        <source>Original project page: %1</source>
        <translation>Özgün proje sayfası: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="366"/>
        <source>MX project page: %1</source>
        <translation>MX proje sayfası: %1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="371"/>
        <source>%1 License</source>
        <translation>%1 Lisans</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="52"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <location filename="../src/about.cpp" line="84"/>
        <source>Changelog</source>
        <translation>Değişim günlüğü</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="32"/>
        <location filename="../src/about.cpp" line="99"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
</context>
<context>
    <name>SaveDialog</name>
    <message>
        <location filename="../src/SaveDialog.cpp" line="21"/>
        <source>Save New Schedule</source>
        <translation>Yeni Çizelgeyi Kaydet</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="34"/>
        <source>User:</source>
        <translation>Kullanıcı:</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="42"/>
        <source>&amp;OK</source>
        <translation>&amp;TAMAM</translation>
    </message>
    <message>
        <location filename="../src/SaveDialog.cpp" line="43"/>
        <source>&amp;Cancel</source>
        <translation>&amp;İptal</translation>
    </message>
</context>
<context>
    <name>TCommandEdit</name>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="43"/>
        <source>User:</source>
        <translation>Kullanıcı:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="51"/>
        <source>Time:</source>
        <translation>Zaman:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="55"/>
        <source>Time String E&amp;ditor</source>
        <translation>Zaman Satırı Düzenleyici</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="60"/>
        <source>Command:</source>
        <translation>Komut:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="66"/>
        <source>Comment:</source>
        <translation>Yorum:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="69"/>
        <source>Job Schedule:</source>
        <translation>İş Çizelgesi:</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="132"/>
        <source>Time Format Error</source>
        <translation>Zaman Biçimi Hatalı</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="146"/>
        <source>No matching schedule</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="155"/>
        <source>Today</source>
        <translation>Bugün</translation>
    </message>
    <message>
        <location filename="../src/TCommandEdit.cpp" line="157"/>
        <source>Tomorrow</source>
        <translation>Yarın</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../src/TimeDialog.cpp" line="80"/>
        <source>time</source>
        <translation>zaman</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="85"/>
        <source>Minute</source>
        <translation>Dakika</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="97"/>
        <source>Hour</source>
        <translation>Saat</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="103"/>
        <source>AM </source>
        <translation>ÖÖ</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="109"/>
        <source>PM </source>
        <translation>ÖS</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="116"/>
        <source>Day</source>
        <translation>Gün</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="131"/>
        <source>Month</source>
        <translation>Ay</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="145"/>
        <source>Week</source>
        <translation>Hafta</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="157"/>
        <source>Simple</source>
        <translation>Basit</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="171"/>
        <source>Enable Literal</source>
        <translation>Literali Etkinleştir</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="173"/>
        <source>&amp;Reset</source>
        <translation>&amp;Sıfırlama</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="174"/>
        <source>&amp;Cancel</source>
        <translation>&amp;İptal</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="175"/>
        <source>&amp;Ok</source>
        <translation>&amp;Tamam</translation>
    </message>
    <message>
        <location filename="../src/TimeDialog.cpp" line="189"/>
        <source>The current time expression is invalid. Please fix it or cancel.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>VariableEdit</name>
    <message>
        <location filename="../src/VariableEdit.cpp" line="50"/>
        <source>Variables</source>
        <translation>Değişkenler</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="55"/>
        <source>Mail:</source>
        <translation>Posta:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="56"/>
        <source>Don&apos;t send</source>
        <translation>Gönderme!</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="57"/>
        <source>Send</source>
        <translation>Gönder</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="58"/>
        <source>To</source>
        <translation>Kime</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="70"/>
        <source>&amp;New</source>
        <translation>&amp;Yeni</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="73"/>
        <source>&amp;Delete</source>
        <translation>&amp;Sil</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="81"/>
        <source>Name:</source>
        <translation>Ad:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="86"/>
        <source>Value:</source>
        <translation>Değer:</translation>
    </message>
    <message>
        <location filename="../src/VariableEdit.cpp" line="89"/>
        <source>Comment:</source>
        <translation>Yorum:</translation>
    </message>
</context>
<context>
    <name>VariableModel</name>
    <message>
        <location filename="../src/VariableModel.cpp" line="37"/>
        <source>Name</source>
        <translation>Ad</translation>
    </message>
    <message>
        <location filename="../src/VariableModel.cpp" line="39"/>
        <source>Value</source>
        <translation>Değer</translation>
    </message>
</context>
</TS>